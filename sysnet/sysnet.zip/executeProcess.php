<?php

	include 'scripts/php/' . $_GET['include'] . '.php';

?>