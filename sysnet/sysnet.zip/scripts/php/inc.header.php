<!DOCTYPE HTML>
<html>
	<head>
		<!-- CSS -->
		<link href="scripts/css/custom-theme/jquery-ui-1.10.3.custom.css" rel="stylesheet" type="text/css">
		<link href="scripts/css/style.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 8]>
			<link rel="stylesheet" type="text/css" href="scripts/css/style_ie.css">
		<![endif]-->


		<!--[if IE 8]>
			<link rel="stylesheet" type="text/css" href="scripts/css/style_ie8.css">
		<![endif]-->

		<!-- Javascript -->
		<script type="text/javascript" src="scripts/js/formFocus.js"></script>

		<!-- JQUERY -->
		<script type="text/javascript" src="scripts/js/jquery-1.9.1.js"></script>
		<script type="text/javascript" src="scripts/js/jquery-ui-1.10.3.custom.js"></script>

		<!-- JQUERY -->
		<script type="text/javascript" src="scripts/js/common.js"></script>

		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>BSDT</title>
	</head>
